package kishor;

public class Student {
//Execution of Variables
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int age;
		age=20;
		
		String name="Rithesh";
		System.out.println("Name: "+name);
		System.out.println("Age : "+age);
	}

}
